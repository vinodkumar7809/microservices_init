insert into exchange_value (id,exchange_from,exchange_to,exchange,port)
values (1001,'USD','INR',65,0);
insert into exchange_value (id,exchange_from,exchange_to,exchange,port)
values (1002,'ERU','INR',55,0);
insert into exchange_value (id,exchange_from,exchange_to,exchange,port)
values (1003,'AUD','INR',35,0);